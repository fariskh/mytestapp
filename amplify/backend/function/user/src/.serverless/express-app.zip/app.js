const serverless = require('serverless-http');
const uploadData = require('aws-amplify/storage');
const express = require('express')
const bodyParser = require('body-parser')
const awsServerlessExpressMiddleware = require('aws-serverless-express/middleware')
const AWS = require('aws-sdk');
const {v4: uuidv1} = require('uuid');
const aws_config = {
  accessKeyId: 'AKIAWIXQJBLS6KPMHMMZ',
  secretAccessKey: 'tdafL+o6JMOIbsMIMVPf8Fos62uS9B0M20jFH8Zm',
  region: 'us-east-1',
};
const YOUR_DOMAIN = 'http://localhost:3000';
const stripe = require('stripe')('sk_test_tR3PYbcVNZZ796tH88S4VQ2u');


const app = express()
app.use(bodyParser.json())
app.use(awsServerlessExpressMiddleware.eventContext())

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*")
  res.header("Access-Control-Allow-Headers", "*")
  next()
});
app.use(express.static('public'));

app.get('/user/get-students', function(req, res) {
  AWS.config.update(aws_config);

  const docClient = new AWS.DynamoDB.DocumentClient();

  const params = {
      TableName: 'Students'
  };

  docClient.scan(params, function (err, data) {

    if (err) {
      console.log(err)
      res.send({
        success: false,
        message: err
      });
    } else {
      const { Items } = data;
      res.send({
        success: true,
        students: Items
      });
    }
  });
})

app.get('/user/add-student', function(req, res) {
    AWS.config.update(aws_config);
    const docClient = new AWS.DynamoDB.DocumentClient();
    const Item = {
      student_id : uuidv1(),
      name : req.query.name,
      student_department_id : req.query.student_department_id,
      age : req.query.age
    };
    var params = {
        TableName: 'Students',
        Item: Item
    };

    // Call DynamoDB to add the item to the table
    docClient.put(params, function (err, data) {
        if (err) {
            res.send({
                success: false,
                message: err
            });
        } else {
            res.send({
                success: true,
                message: 'Added Student '+ Item.name,
                student: data
            });
        }
    });
})

app.get('/user', function(req, res) {
  res.json({success: 'My new changes here!', url: req.url});
});

app.get('/user/home', function(req, res) {
  res.json({success: 'Home!', url: req.url});
});

app.get('/user/logout', function(req, res) {
  res.json({success: 'Main', url: req.url});
});



app.get('/set-stripe', async function(req, res) {
  let product = await stripe.products.create({
    name: 'Starter Subscription',
    description: '$12/Month subscription',
  });
  let price = await stripe.prices.create({
    unit_amount: 1200,
    currency: 'usd',
    recurring: {
      interval: 'month',
    },
    product: product.id,
  });
  console.log('Success! Here is your starter subscription product id: ' + product.id);
  console.log('Success! Here is your starter subscription price id: ' + price.id);
  res.json({success: 'Main', url: req.url});
});


app.get('/try-stripe', async function(req, res) {
    const session = await stripe.checkout.sessions.create({
    line_items: [
      {
        // Provide the exact Price ID (for example, pr_1234) of the product you want to sell
        price: 'price_1Oerx9JAJfZb9HEBa7foaKri',
        quantity: 1,
      },
    ],
    mode: 'payment',
    success_url: `${YOUR_DOMAIN}/success.html`,
    cancel_url: `${YOUR_DOMAIN}/cancel.html`,
  });

  res.redirect(session.url);
});



app.get('/upload-file', async function(req, res) {
  try {
    const result = await uploadData({
      key: filename,
      data: file,
      options: {
        accessLevel: 'guest', // defaults to `guest` but can be 'private' | 'protected' | 'guest'
        onProgress // Optional progress callback.
      }
    }).result;
    console.log('Succeeded: ', result);
  } catch (error) {
    console.log('Error : ', error);
  }
})




app.listen(3000, function() {
    console.log("App started")
});

// module.exports = app
module.exports.handler = serverless(app)
